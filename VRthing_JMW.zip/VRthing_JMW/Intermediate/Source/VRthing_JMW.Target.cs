using UnrealBuildTool;

public class VRthing_JMWTarget : TargetRules
{
	public VRthing_JMWTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Game;
		ExtraModuleNames.Add("VRthing_JMW");
	}
}
