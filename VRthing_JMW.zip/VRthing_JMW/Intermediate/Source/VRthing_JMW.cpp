#include "CoreTypes.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultModuleImpl, VRthing_JMW, "VRthing_JMW");
